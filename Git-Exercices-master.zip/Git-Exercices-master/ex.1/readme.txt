You have accidentaly put first.txt in the staging area
While you actually want to only commit second.txt.

You need to, from the current state, only commit second.txt.

- Remove the file second.txt (Use `git status` to get the appropriate command`)
- Add first.txt
- Commit
