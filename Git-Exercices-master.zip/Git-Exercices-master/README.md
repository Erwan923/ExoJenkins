Simple Git Exercices
====================

Theses are very simple exercices to learn to manipulate git.

These are not even real exercices, more like DIY guides to learn to handle
very common situations.

In each folder, simply run ./create.sh and follow the guide ;)

*The create script in each folder will completely reset the exercice.*  
If you want to re-read the instructions of the exercice, just cat
the file readme.txt.

-----

If you enjoyed those exercices, I strongly encourage you to look further
into Git as those are very simple situations and there are loads of
tips and tricks that these exercices do not cover.
