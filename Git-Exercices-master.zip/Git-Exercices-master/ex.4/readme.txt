PART 1:
You have worked hard and the result is beautiful.
But somehow there's a bug.

It's late, your partner wants you to go home.

Hell, maybe a good night sleep (or a good night something else)
will help you find that stupid bug.

So you want to go home, but you don't want to leave the work unsaved,
that would be unprofessional. And you're a pro.

So, as the code cannot be merged into master yet, you decide to create a branch.

- Create and checkout a new branch named "file-second"
- Commit the current state
- Push it (remember, the branch does not exists yet on origin)


PART 2:
Your mind is clear and ready to tackle that nasty bug.
As you march to your desk like the conquerant you are, your boss stops you.

There's an urgent fix that needs to go out in prod just. right. now.

- Checkout the branch master
- Pull it to get the last version
- Add a "three" to the file first.txt
- Commit and push the changes to that new file


PART 3:
Now is the time to tackle the problem, let's get back to your work.

- Checkout the branch file-second


PART 4:
Of couuuuurse !
You found it, the 'E' is missing between 'D' and 'F'

After fixing the bug, the awesomeness can be mnerged into master.

- Modify the file so that it's beauty is complete
- Commit the difference
- Push it
- Merge it into master
- Push master
- Brag


PART 5:
You are a good citizen (or at least in this story we assume you are).
You are not working anymore on the branch file-second

- Delete the branch file-second both localy and in origin
