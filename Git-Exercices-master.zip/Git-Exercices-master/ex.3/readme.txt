You just realized that you have commited a backup file: main.cpp~.

Backup files should not be commited, let's correct that mistake.

- Delete the file with `rm`
- Add all changes, including deleted files with `git add -A`
- Write a gitignore that will correct your mistake
- Add it
- Commit
