Oh no!!!
You have just made a commit amend on a commit that were already pushed!
Worst yet: someone has already pushed a new commit on top.

Your branch master and origin/master have diverged.

Fix it!
